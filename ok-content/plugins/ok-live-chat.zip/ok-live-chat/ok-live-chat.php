<?php
/*
Plugin Name: OK Live Chat (Modular)
Description: ლაივ ჩატი OK CMS-ისთვის: Telegram სინქრონიზაცია + AI.
Version: 14.0
Author: OK Engine
*/

if (!defined('OK_LOADED')) exit;

// კონფიგურაცია
define('OK_CHAT_KEY', 'Secret_Key_Change_Me_XYZ'); // შეცვალეთ ეს
define('OK_CIPHER', 'aes-256-cbc');
define('OK_CHAT_DIR', __DIR__ . '/includes/');

// მოდულების ჩატვირთვა
require_once OK_CHAT_DIR . 'db.php';
require_once OK_CHAT_DIR . 'telegram.php';
require_once OK_CHAT_DIR . 'api.php';
require_once OK_CHAT_DIR . 'admin.php';
require_once OK_CHAT_DIR . 'frontend.php';

// სისტემის გაშვება (OK CMS Hook)
add_ok_action('init', function() {
    // 1. ბაზის შექმნა
    ok_chat_install_db();

    // 2. Telegram Webhook მოსმენა (?ok_tg_hook=1)
    if (isset($_GET['ok_tg_hook'])) {
        OK_Chat_Telegram::handle_webhook();
    }

    // 3. API მოსმენა
    if (isset($_POST['ok_chat_action'])) {
        ok_chat_handle_api();
    }
});